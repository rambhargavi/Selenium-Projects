package io;

import java.io.*;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;



public class ReadTestCase
{
	public String[][] readExcel(String fileName,String sheetName)
	{
		String[][] excelData=null;
		try{
			FileInputStream fis=new FileInputStream(fileName);
			if(fis!=null)
			{
				Workbook wbook=Workbook.getWorkbook(fis);
				Sheet sheet=wbook.getSheet(sheetName);
				int rows,cols;
				rows=sheet.getRows();
				cols=sheet.getColumns();
				excelData=new String[rows-1][cols];
				for(int i=1;i<rows;i++)
				{
					for(int j=0;j<cols;j++)
					{
						excelData[i-1][j]=sheet.getCell(j, i).getContents();
					}
				}
			}
		}catch(FileNotFoundException e)
		{
			System.out.println(e.getMessage());
		}catch(IOException e)
		{
			System.out.println(e.getMessage());
		}catch(BiffException e)
		{
			System.out.println(e.getMessage());
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	 return excelData;
	}
}
