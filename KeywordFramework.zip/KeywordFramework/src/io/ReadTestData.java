package io;
import java.io.*;

import jxl.Sheet;
import jxl.Workbook;
public class ReadTestData 
{
	String[][] data=null;
  public String[][] readData(String fileName)
  {
	 try{
		 FileInputStream fis=new FileInputStream(fileName);
		 Workbook wbook=Workbook.getWorkbook(fis);
		 Sheet sh=wbook.getSheet("Sheet1");
		 int rows=sh.getRows();
		 int cols=sh.getColumns();
		 data=new String[rows-1][cols];
		 for(int i=1;i<rows;i++)
		 {
			 for(int j=0;j<cols;j++)
			 {
				 data[i-1][j]=sh.getCell(j,i).getContents();
			 }
		 }
		 
	 }catch(FileNotFoundException ex)
	 {
		 System.out.println(ex.getMessage());
	 }catch(IOException ex)
	 {
		 System.out.println(ex.getMessage());
	 }catch(Exception ex)
	 {
		 System.out.println(ex.getMessage());
	 }
	 return data;
  }
}
