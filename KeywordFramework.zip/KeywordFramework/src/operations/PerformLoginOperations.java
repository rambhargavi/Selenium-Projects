package operations;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PerformLoginOperations
{
	WebDriver wd=null;
	Boolean flag=null;
	By by=null;
	public void performOperations(String[][] steps,String userid,String password)throws Exception
	{
		
	for(int i=0;i<steps.length;i++)
		{
			//System.out.println(arrayOperations[i][1]+"::"+arrayOperations[i][2]+"::"+arrayOperations[i][3]);
		try{
			switch(steps[i][2])
			{
			case "open_browser":
				wd= open_browser(steps[i][5]);
				break;
			case "navigate_to":
				navigate_to(wd,steps[i][5]);
				break;
			case "send_keys":
				if(steps[i][1].contains("userid"))
				wd.findElement(this.getObject(steps[i][3],steps[i][4])).sendKeys(userid);
				else if(steps[i][1].contains("Password"))
				wd.findElement(this.getObject(steps[i][3],steps[i][4])).sendKeys(password);	
				break;
			case "click_element":
				wd.findElement(this.getObject(steps[i][3],steps[i][4])).click();
				break;
			case "verify_element":
				verify_element(wd,steps[i][3],steps[i][4]);
				break;
			case "mover_element":
				mover_element(wd,steps[i][3],steps[i][4]);
				break;
			case "close_browser":
				wd.quit();
				break;
			default:
				throw new Exception("Invalid Login");
				
			}
		}catch(Exception ex)
		{
			System.out.println(ex.getMessage());
			Assert.assertTrue(false);
			wd.quit();
		}
		}
	}	
		
	  public WebDriver open_browser(String browserName)
		{
			if(browserName.equals("firefox"))
			{
				wd=new FirefoxDriver();
			}
			wd.manage().window().maximize();
			wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			return wd;	
		}
	  public void navigate_to(WebDriver wd,String url)
	  {
		  wd.get(url);
	  }
	  
	  public void mover_element(WebDriver wd,String locatorType,String locatorString)throws Exception
	  {
		 WebElement we=wd.findElement(this.getObject(locatorType,locatorString));
		new Actions(wd).moveToElement(we).perform();
	  }
	  
	  public void verify_element(WebDriver wd,String locatorType,String locatorString)throws Exception
	  {
		  WebDriverWait wait=new WebDriverWait(wd,60);
			wait.until(ExpectedConditions.visibilityOfElementLocated(this.getObject(locatorType,locatorString)));
			if(wd.findElement(this.getObject(locatorType, locatorString)).isDisplayed())
			{
				flag=true;
				Assert.assertTrue(flag);
			}else 
			{
				flag=false;
				throw new Exception("Cound not verify");
			}
	  }
	 private By getObject(String locatorType,String locatorString)throws Exception
	  {
		
		if(locatorType.equals("xpath"))
		{
			by=By.xpath(locatorString);
		}
		else if(locatorType.equals("id"))
		{
			by=By.id(locatorString);
		}
		else if(locatorType.equals("linkText"))
		{
			by=By.linkText(locatorString);
		}
		else throw new Exception("wrong locator type");
		
		return by;
	}
				
}


