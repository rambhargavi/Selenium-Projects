package tests;
import junit.framework.Assert;
import io.ReadTestCase;
import io.ReadTestData;
import operations.PerformLoginOperations;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestLogin 
{
	String fileName1="C:\\Selenium\\PractisePrograms\\KeywordFramework\\testcase.xls";
	String fileName2="C:\\Selenium\\PractisePrograms\\KeywordFramework\\testdata.xls";
	String sheetName="Sheet1";
	ReadTestCase readTestCase=null;
	PerformLoginOperations perform=null;
	ReadTestData readTestData=null;
	
	@BeforeClass
	public void setup()
	{
		readTestCase=new ReadTestCase();
		perform=new PerformLoginOperations();
		readTestData=new ReadTestData();
	}
   @Test(dataProvider="LoginData")
   public void performTest(String userid,String password)
    {
	  try{
	  String[][] arrayObject=readTestCase.readExcel(fileName1, sheetName);
	  perform.performOperations(arrayObject,userid,password);
	  }catch(Exception e)
	  {
		  System.out.println(e.getMessage());
		  Assert.assertTrue(false);
	  }
	  
  }
  
  @DataProvider(name="LoginData") 
  public Object[][] getTestData()
  {
	  String data[][]=readTestData.readData(fileName2);
	  return data;
  }
  
  
}
