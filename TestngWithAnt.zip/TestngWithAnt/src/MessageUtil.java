
public class MessageUtil
{
	String message;
public MessageUtil(String message)
{
	this.message=message;
}
public void printMessage()
{
	System.out.println("Inside printMessage:::"+message);
}

public void printSalutationMessage()
{
	System.out.println("Inside Salutation Message:::"+"Hi!  "+message);
}
}
