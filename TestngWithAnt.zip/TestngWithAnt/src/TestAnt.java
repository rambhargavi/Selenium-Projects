import org.testng.annotations.Test;
public class TestAnt
{
	String message="Bhargavi";
	@Test
  public void testAnt() throws Exception
  {
	  System.out.println("Inside testAnt");
	  MessageUtil mu=new MessageUtil(message);
	  mu.printMessage();
	  mu.printSalutationMessage();
	  DeltaSearch ds=new DeltaSearch();
	  ds.open();
	  ds.search_flight();
	  ds.book_flight();
	  ds.passenger_information();
  }
}
