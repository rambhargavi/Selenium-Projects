import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.*;


public class DeltaSearch
{
 FirefoxDriver driver;
  Logger log=Logger.getLogger("DeltaSearch");
	public void open()
	{
		PropertyConfigurator.configure("C:\\Selenium\\JavaPrograms\\TestngWithAnt\\log\\log4j.properties");
		driver=new FirefoxDriver();
		driver.get("http://www.delta.com");
		log.debug("application opened");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	public void search_flight()
	{
		driver.findElement(By.id("roundTripBtn")).click();
		driver.findElement(By.id("originCity")).sendKeys("BNA");
		driver.findElement(By.id("destinationCity")).sendKeys("ORD");
		driver.findElement(By.id("departureDate")).click();
		driver.findElement(By.xpath("//div[@class='cal1']//table//tbody//tr[4]//td[3]")).click();
		driver.findElement(By.id("returnDate")).click();
		driver.findElement(By.xpath("//div[@class='cal2']//table//tbody//tr[3]//td[4]")).click();
		driver.findElement(By.id("exactDaysBtn")).click();
		driver.findElement(By.id("cashBtn")).click();
		new Select(driver.findElement(By.id("paxCount"))).selectByVisibleText("2");
		driver.findElement(By.id("findFlightsSubmit")).click();
		log.debug("search data in"+driver.getTitle());
		
	    if(driver.getTitle().equals("Delta - Book a flight"))
	    {
	    	System.out.println("Search successful");
	    	log.debug("Search completed");
		}
	}
	
	public void book_flight()
	{
		try{
		WebDriverWait wait = new WebDriverWait(driver,50);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//select[@id='sortType']")));
        new Select(driver.findElement(By.id("sortType"))).selectByVisibleText("Price");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='0_0_0']")));
		driver.findElement(By.id("0_0_0")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//select[@id='sortType']")));
		new Select(driver.findElement(By.id("sortType"))).selectByVisibleText("Price");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='0_0_0']")));
		driver.findElement(By.id("0_0_0")).click();
		log.debug("Booking in progress :::"+driver.getTitle());
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@id='tripContinueButtonWrap']//button")));
		driver.findElement(By.xpath("//div[@id='tripContinueButtonWrap']//button")).click();
		}catch(Exception ex)
		{
			log.debug("Exception"+ex.getMessage());
		}

	}
	
	public void passenger_information() throws Exception
	{
		try
		{
		log.debug("Page Info::"+driver.getTitle());
		//1st passenger info
		new Select(driver.findElement(By.id("prefix0"))).selectByVisibleText("Mr");
		driver.findElement(By.id("firstName0")).sendKeys("John");
		driver.findElement(By.id("lastName0")).sendKeys("Smith");
		new Select(driver.findElement(By.id("gender0"))).selectByVisibleText("Male");
		new Select(driver.findElement(By.id("month0"))).selectByVisibleText("January");
		new Select(driver.findElement(By.id("day0"))).selectByVisibleText("3");
		new Select(driver.findElement(By.id("year0"))).selectByVisibleText("1982");
		//2nd passenger info
		new Select(driver.findElement(By.id("prefix1"))).selectByVisibleText("Mrs");
		driver.findElement(By.id("firstName1")).sendKeys("Alisha");
		driver.findElement(By.id("lastName1")).sendKeys("Smith");
		new Select(driver.findElement(By.id("gender1"))).selectByVisibleText("Female");
		new Select(driver.findElement(By.id("month1"))).selectByVisibleText("December");
		new Select(driver.findElement(By.id("day1"))).selectByVisibleText("13");
		new Select(driver.findElement(By.id("year1"))).selectByVisibleText("1985");
		//contact information
		driver.findElement(By.id("telephoneNumber0")).sendKeys("8457779997");
		driver.findElement(By.id("email")).sendKeys("alisha_smith@gmail.com");
		driver.findElement(By.id("reEmail")).sendKeys("alisha_smith@gmail.com");
		driver.findElement(By.id("paxReviewPurchaseBtn")).click();
		if(driver.getTitle().equals("Delta : Passenger Information Page."))
		{
		log.debug("booking completed");
		File f=driver.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(f,new File("C:\\Selenium\\JavaPrograms\\TestngWithAnt\\resources\\booking.jpg"));
		}
		}catch(Exception e)
		{
			log.debug(e.getMessage());
			File f=driver.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(f,new File("C:\\Selenium\\JavaPrograms\\TestngWithAnt\\resources\\error.jpg"));

		}
      
	}
	
	}
	

