package tests;

import io.ReadTestCase;
import operations.PerformOperations;
import operations.VerifyFBLogin;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import atu.testng.reports.ATUReports;
import atu.testng.reports.listeners.ATUReportsListener;
import atu.testng.reports.listeners.ConfigurationListener;
import atu.testng.reports.listeners.MethodListener;
import atu.testng.reports.logging.LogAs;
import atu.testng.selenium.reports.CaptureScreen;
import atu.testng.selenium.reports.CaptureScreen.ScreenshotOf;


public class TestFB 
{
	ReadTestCase readCase;
	VerifyFBLogin fbLogin;
	String[][] data;

	@BeforeClass
	public void createInstances()
	{
		readCase=new ReadTestCase();
		fbLogin=new VerifyFBLogin();
	}
	@Test(dataProvider="fbLoginData")
	public void testFBLogin(String userid,String pass)
	{
		fbLogin.verifyLogin(userid,pass);	
	}
	@DataProvider(name="fbLoginData")
	public String[][] getData()
	{
		data=readCase.readTestCase("FBLoginData");
		return data;
	}

}
