package tests;

import io.ReadTestCase;

import java.util.*;

import operations.CalculateDeal;
import operations.PerformOperations;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import atu.testng.reports.ATUReports;
import atu.testng.reports.listeners.ATUReportsListener;
import atu.testng.reports.listeners.ConfigurationListener;
import atu.testng.reports.listeners.MethodListener;
import atu.testng.reports.logging.LogAs;
import atu.testng.selenium.reports.CaptureScreen;
import atu.testng.selenium.reports.CaptureScreen.ScreenshotOf;


public class TestFlightDeal
 {
	ReadTestCase readData;
	CalculateDeal deal;
	
   @Test(dataProvider="FlightData")
  public void testDeal(String ori,String dest,String from,String to)
  {
     deal.getDeal("FlightSearch",ori,dest,from,to);
  }
  
  @DataProvider(name="FlightData")
  public String[][] getTestData()
  {
	 String data[][]= readData.readTestCase("FlightData");
	 return data;
  }
  @BeforeClass
  public void initObject()
  {
	  readData=new ReadTestCase();
	  deal=new CalculateDeal();
  }
  
}
