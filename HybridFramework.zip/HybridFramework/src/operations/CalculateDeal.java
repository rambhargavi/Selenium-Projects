package operations;

import io.ReadProp;
import io.ReadTestCase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Listeners;

import atu.testng.reports.ATUReports;
import atu.testng.reports.listeners.ATUReportsListener;
import atu.testng.reports.listeners.ConfigurationListener;
import atu.testng.reports.listeners.MethodListener;
import atu.testng.reports.logging.LogAs;
import atu.testng.selenium.reports.CaptureScreen;
import atu.testng.selenium.reports.CaptureScreen.ScreenshotOf;

@Listeners({ATUReportsListener.class, ConfigurationListener.class, MethodListener.class})
public class CalculateDeal 
{
	String price;
	String itin;
	By by=null;
	WebDriverWait wait;
	ReadProp read;
	ReadTestCase readTest;
	PerformOperations perform;
	HashMap hMap;
	Properties prop;
	private final Logger log=Logger.getLogger("operations");
	double fprice;
	
	{
		System.setProperty("atu.reporter.config","C:\\Selenium\\PractisePrograms\\HybridFramework\\atu.properties");
    }
	public CalculateDeal()
	{
		read=new ReadProp();
		readTest=new ReadTestCase();
		perform=new PerformOperations();
		prop=read.readFile();
	}
	
	public void getDeal(String sheetName,String origin,String dest,String from,String to)
	{
		hMap=new HashMap();	
	  PropertyConfigurator.configure("C:\\Selenium\\PractisePrograms\\HybridFramework\\logs\\log4j.properties");
	   itin="ORIGIN::"+origin+"DESTINATION::"+dest+"FROM DATE::"+from+"TO DATE::"+to;
		String[][] steps=readTest.readTestCase(sheetName);
		for(int i=0;i<steps.length;i++)
		{
			log.info(steps[i][1]+"::"+steps[i][2]+"::"+steps[i][3]);
			try{
				switch(steps[i][3])
				{
				case "open_browser":
					perform.openBrowser();
					break;
				case "navigate_url":
					perform.navigateURL(steps[i][5],prop);
					break;
				case "on_click":
					perform.onClick(steps[i][4],steps[i][5],prop);
					break;
				case "send_text":
					perform.sendFlightText(steps[i][2],steps[i][4],steps[i][5],prop,origin,dest,from,to);
					break;
				case "explicit_wait":
					perform.explicitWait(wait,steps[i][4],steps[i][5],prop);
					break;
				case "convert_price":
					fprice=perform.convertFlightPrice(steps[i][4],steps[i][5],prop);	
					log.info("Float price value:"+fprice);
					hMap.put(fprice,itin);
					ATUReports.add("Flight Search",origin,dest,LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));
				   break;
				case "close_browser":
					perform.closeBrowser();
					break;
				default:
					break;	
				}
			}catch(Exception ex)
			{
				log.error(ex.getMessage());
				ATUReports.add("Flight Search",origin,dest,LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));				
				Assert.assertTrue(false);
				perform.closeBrowser();
			
			}
		}
		ArrayList list=new ArrayList(hMap.keySet());
		Collections.sort(list);
		log.info("Best Offer for itenary "+hMap.get(list.get(0))+" :::@ $"+list.get(0));
		Assert.assertTrue(true);
	
	}
}

