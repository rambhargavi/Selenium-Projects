package operations;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;



import io.ReadProp;
import io.ReadTestCase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class PerformOperations 
{
	By by=null;
	WebDriver fd;
	String price;
	double fprice;
	static Logger log=null;
	public PerformOperations()
	{
		log=Logger.getLogger("PerformOperations");
	}

	public void openBrowser()
	{
		fd=new FirefoxDriver();	
	}
	public void closeBrowser()
	{
		fd.quit();
	}
	public void navigateURL(String locatorString,Properties prop)
	{
       fd.get(prop.getProperty(locatorString));	
       fd.manage().window().maximize();
	   fd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	public void onClick(String locatorType,String locatorString,Properties prop)
	{
		fd.findElement(this.getObject(locatorType, locatorString, prop)).click();
	}
	public void explicitWait(WebDriverWait wait,String locatorType,String locatorString,Properties prop)
	{
		wait= new WebDriverWait(fd,60);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(this.getObject(locatorType, locatorString, prop)));
	    if(fd.findElement(this.getObject(locatorType, locatorString, prop)).isDisplayed())
	    {
	    	Assert.assertTrue(true);
	    	log.info("element found");
	    }
	    else{
	    	log.info(locatorString+" not found");
	    	Assert.assertTrue(false);
	    }
	    
	}
	public void sendFlightText(String steps,String locatorType,String locatorString,Properties prop,String origin,String dest,String from,String to)
	{
		if(steps.contains("origin"))
			fd.findElement(this.getObject(locatorType, locatorString, prop)).sendKeys(origin);
		else if(steps.contains("destination"))
			fd.findElement(this.getObject(locatorType, locatorString, prop)).sendKeys(dest);
		else if(steps.contains("departure"))
			fd.findElement(this.getObject(locatorType, locatorString, prop)).sendKeys(from);
		else if(steps.contains("return"))
			fd.findElement(this.getObject(locatorType, locatorString, prop)).sendKeys(to);
	}
	public void sendFBLoginText(String steps,String locatorType,String locatorString,Properties prop,String userid,String pass)
	{
		if(steps.contains("userid"))
			fd.findElement(this.getObject(locatorType, locatorString, prop)).sendKeys(userid);
		else if(steps.contains("password"))
			fd.findElement(this.getObject(locatorType, locatorString, prop)).sendKeys(pass);
	}
	public double convertFlightPrice(String locatorType,String locatorString,Properties prop)
	{
		price=fd.findElement(this.getObject(locatorType, locatorString, prop)).getText().replace("$", " ");
		fprice=Double.parseDouble(price);
		return fprice;
	}
	public By getObject(String locatorType,String locatorString,Properties prop)
	{
		try{
		if(locatorType.equals("xpath"))
		{
			by=By.xpath(prop.getProperty(locatorString));
		}else if(locatorType.equals("id"))
		{
			by=By.id(prop.getProperty(locatorString));
		}else if(locatorType.equals("linkText"))
		{
			by=By.linkText(prop.getProperty(locatorString));
		}else if(locatorType.equals("name"))
		{
			by=By.name(prop.getProperty(locatorString));
		}
		else throw new Exception("Invalid Locator type");
		}catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
			
		return by;
	}

}
