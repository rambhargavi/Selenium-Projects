package operations;

import java.util.Properties;



import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Listeners;

import atu.testng.reports.ATUReports;
import atu.testng.reports.listeners.ATUReportsListener;
import atu.testng.reports.listeners.ConfigurationListener;
import atu.testng.reports.listeners.MethodListener;
import atu.testng.reports.logging.LogAs;
import atu.testng.selenium.reports.CaptureScreen;
import atu.testng.selenium.reports.CaptureScreen.ScreenshotOf;
import io.ReadProp;
import io.ReadTestCase;

@Listeners({ATUReportsListener.class, ConfigurationListener.class, MethodListener.class})
public class VerifyFBLogin 
{
   ReadTestCase readCase;	
   PerformOperations perform;
   ReadProp readProp;
   Properties prop;
   WebDriverWait wait;

   private static final Logger log=Logger.getLogger("operations");
   
   {
		System.setProperty("atu.reporter.config","C:\\Selenium\\PractisePrograms\\HybridFramework\\atu.properties");
   }
	public VerifyFBLogin()
	{
		readCase=new ReadTestCase();
		perform=new PerformOperations();
		readProp=new ReadProp();
		prop=readProp.readFile();
	}
	public void verifyLogin(String userid,String pass)
	{
		 PropertyConfigurator.configure("C:\\Selenium\\PractisePrograms\\HybridFramework\\logs\\log4j.properties");
		 String[][] steps=readCase.readTestCase("FBLogin");
	     for(int i=0;i<steps.length;i++)
	   {
		  log.info(steps[i][1]+"::"+steps[i][2]+"::"+steps[i][3]);
	    try{
	    	
		  switch(steps[i][3])
		  {
		  case "open_browser":
			  perform.openBrowser();
			  break;
		  case "navigate_url":
			  perform.navigateURL(steps[i][5], prop);
			  break;
		  case "send_text":
			  perform.sendFBLoginText(steps[i][2],steps[i][4],steps[i][5],prop,userid,pass);
			  break;
		  case "on_click":
			  perform.onClick(steps[i][4],steps[i][5],prop);
			  break;
		  case "explicit_wait":
			  perform.explicitWait(wait,steps[i][4],steps[i][5],prop);
			  ATUReports.add("Login success","FBLogin",userid,LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));
			  Assert.assertTrue(true);
			  break;
		  case "close_browser":
			  perform.closeBrowser();
			  break;
			  default:
				  break;
		  }
	  
	    }catch(Exception e)
	    {
		  log.error(e.getMessage());
		  ATUReports.add("Login failed","FBLogin",userid,LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));		  
		  Assert.assertTrue(false);
		  perform.closeBrowser(); 
	
	    }
	  }

   }
 }
