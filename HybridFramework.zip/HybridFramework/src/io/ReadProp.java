package io;

import java.io.*;
import java.util.Properties;

public class ReadProp
{
	private String fileName="C:\\Selenium\\PractisePrograms\\HybridFramework\\resources\\project.properties";
	Properties prop;
	public Properties readFile()
	{
		prop=new Properties();
		try{
		FileInputStream is=new FileInputStream(fileName);
		if(is!=null)
			prop.load(is);
		}catch(FileNotFoundException ex)
		{
			System.out.println(ex.getMessage());	
		}catch(IOException ex)
		{
			System.out.println(ex.getMessage());
		}catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
		return prop;
	}
	
}
