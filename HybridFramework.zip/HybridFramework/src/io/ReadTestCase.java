package io;
import java.io.*;

import jxl.*;

public class ReadTestCase 
{
	public String[][] testCase;
	String fileName="C:\\Selenium\\PractisePrograms\\HybridFramework\\resources\\TestSuite.xls";

	public String[][] readTestCase(String sheetName)
	{
		int rows,cols;
		try{
		FileInputStream fis=new FileInputStream(fileName);
		if(fis!=null)
		{
			Workbook wbook=Workbook.getWorkbook(fis);
			Sheet sheet=wbook.getSheet(sheetName);
			rows=sheet.getRows();
			cols=sheet.getColumns();
			testCase=new String[rows-1][cols];
			for(int i=1;i<rows;i++)
			{
				for(int j=0;j<cols;j++)
				{
					testCase[i-1][j]=sheet.getCell(j, i).getContents();
				}
			}
			
		}
		
		}catch(FileNotFoundException ex)
		{
			System.out.println(ex.getMessage());	
		}catch(IOException ex)
		{
			System.out.println(ex.getMessage());
		}catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
		return testCase;
	}
	
}
